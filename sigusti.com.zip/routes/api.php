<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\LicenseController;

// License API endpoints
