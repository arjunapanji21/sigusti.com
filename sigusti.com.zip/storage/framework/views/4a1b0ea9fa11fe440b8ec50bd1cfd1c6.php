<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" type="image/x-icon" href="<?php echo e(url(asset('favicon.ico'))); ?>">
    <title><?php echo e(isset($title) ? $title : 'Error'); ?> - <?php echo e(config('app.name', 'SI-GUSTI')); ?></title>
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=inter:400,500,600,700" rel="stylesheet" />
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="font-sans antialiased bg-background">
    <div class="min-h-screen flex flex-col justify-center items-center">
        <!-- Page Content -->
        <main>
            <?php echo e($slot); ?>

        </main>
        
        <!-- Footer -->
        <footer class="mt-8 text-center text-base-light text-sm">
            <p>&copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name', 'SI-GUSTI')); ?>. All rights reserved.</p>
        </footer>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\sigusti.com\resources\views/layouts/error.blade.php ENDPATH**/ ?>