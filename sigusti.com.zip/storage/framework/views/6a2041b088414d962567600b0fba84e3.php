<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-6">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            <!-- Header -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 border-b border-gray-200">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <a href="<?php echo e(route('pemeriksaan.index')); ?>" class="mr-4 text-gray-500 hover:text-gray-700">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                                </svg>
                            </a>
                            <div>
                                <h1 class="text-2xl font-bold text-gray-900">Detail Pemeriksaan</h1>
                                <p class="mt-1 text-sm text-gray-600">
                                    <?php echo e($pemeriksaan->nama_balita); ?> • <?php echo e($pemeriksaan->created_at->format('d M Y H:i')); ?>

                                </p>
                            </div>
                        </div>
                        <div class="flex space-x-3">
                            <a href="<?php echo e(route('pemeriksaan.print', $pemeriksaan->id)); ?>" 
                               target="_blank"
                               class="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/>
                                </svg>
                                Cetak
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Screen Display Content -->
            <div>
                <!-- Data Balita -->
                <div class="bg-white shadow sm:rounded-lg mb-6">
                    <div class="px-4 py-5 sm:p-6">
                        <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Data Balita</h3>
                        <dl class="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
                            <div>
                                <dt class="text-sm font-medium text-gray-500">Nama Balita</dt>
                                <dd class="mt-1 text-sm text-gray-900"><?php echo e($pemeriksaan->nama_balita); ?></dd>
                            </div>
                            <div>
                                <dt class="text-sm font-medium text-gray-500">Jenis Kelamin</dt>
                                <dd class="mt-1 text-sm text-gray-900"><?php echo e($pemeriksaan->gender == 'L' ? 'Laki-laki' : 'Perempuan'); ?></dd>
                            </div>
                            <div>
                                <dt class="text-sm font-medium text-gray-500">Usia Saat Pemeriksaan</dt>
                                <dd class="mt-1 text-sm text-gray-900"><?php echo e($pemeriksaan->usia_saat_pemeriksaan); ?> bulan</dd>
                            </div>
                            <div>
                                <dt class="text-sm font-medium text-gray-500">Berat Badan</dt>
                                <dd class="mt-1 text-sm text-gray-900"><?php echo e($pemeriksaan->berat); ?> kg</dd>
                            </div>
                        </dl>
                    </div>
                </div>

                <!-- Hasil Pemeriksaan -->
                <div class="bg-white shadow sm:rounded-lg mb-6">
                    <div class="px-4 py-5 sm:p-6">
                        <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Hasil Pemeriksaan</h3>
                        <div class="grid grid-cols-1 gap-6 sm:grid-cols-2">
                            <!-- Status Pertumbuhan -->
                            <div class="border border-gray-200 rounded-lg p-4">
                                <div class="flex items-center">
                                    <?php if($pemeriksaan->kode_pertumbuhan == 'normal'): ?>
                                        <div class="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mr-3">
                                            <svg class="w-6 h-6 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                                                <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                            </svg>
                                        </div>
                                    <?php else: ?>
                                        <div class="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center mr-3">
                                            <svg class="w-6 h-6 text-yellow-600" fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
                                            </svg>
                                        </div>
                                    <?php endif; ?>
                                    <div>
                                        <h4 class="text-sm font-medium text-gray-900">Status Pertumbuhan</h4>
                                        <p class="text-sm 
                                            <?php if($pemeriksaan->kode_pertumbuhan == 'normal'): ?> text-green-600
                                            <?php elseif($pemeriksaan->kode_pertumbuhan == 'kurang'): ?> text-yellow-600
                                            <?php elseif($pemeriksaan->kode_pertumbuhan == 'sangat_kurang'): ?> text-red-600
                                            <?php elseif($pemeriksaan->kode_pertumbuhan == 'lebih'): ?> text-orange-600
                                            <?php endif; ?>">
                                            <?php echo e(ucfirst(str_replace('_', ' ', $pemeriksaan->kode_pertumbuhan))); ?>

                                        </p>
                                    </div>
                                </div>
                            </div>

                            <!-- Status Perkembangan -->
                            <div class="border border-gray-200 rounded-lg p-4">
                                <div class="flex items-center">
                                    <?php if($pemeriksaan->kode_tindakan_perkembangan == 'sesuai'): ?>
                                        <div class="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mr-3">
                                            <svg class="w-6 h-6 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                                                <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                            </svg>
                                        </div>
                                    <?php elseif($pemeriksaan->kode_tindakan_perkembangan == 'meragukan'): ?>
                                        <div class="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center mr-3">
                                            <svg class="w-6 h-6 text-yellow-600" fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
                                            </svg>
                                        </div>
                                    <?php else: ?>
                                        <div class="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center mr-3">
                                            <svg class="w-6 h-6 text-red-600" fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
                                            </svg>
                                        </div>
                                    <?php endif; ?>
                                    <div>
                                        <h4 class="text-sm font-medium text-gray-900">Status Perkembangan</h4>
                                        <p class="text-sm 
                                            <?php if($pemeriksaan->kode_tindakan_perkembangan == 'sesuai'): ?> text-green-600
                                            <?php elseif($pemeriksaan->kode_tindakan_perkembangan == 'meragukan'): ?> text-yellow-600
                                            <?php else: ?> text-red-600
                                            <?php endif; ?>">
                                            <?php echo e(ucfirst($pemeriksaan->kode_tindakan_perkembangan)); ?>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Jadwal Kontrol -->
                <div class="bg-white shadow sm:rounded-lg mb-6">
                    <div class="px-4 py-5 sm:p-6">
                        <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Jadwal Kontrol Selanjutnya</h3>
                        <dl class="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
                            <div>
                                <dt class="text-sm font-medium text-gray-500">Jadwal Pertumbuhan</dt>
                                <dd class="mt-1 text-sm text-gray-900"><?php echo e(\Carbon\Carbon::parse($pemeriksaan->jadwal_pertumbuhan)->format('d M Y')); ?></dd>
                            </div>
                            <div>
                                <dt class="text-sm font-medium text-gray-500">Jadwal Perkembangan</dt>
                                <dd class="mt-1 text-sm text-gray-900"><?php echo e(\Carbon\Carbon::parse($pemeriksaan->jadwal_perkembangan)->format('d M Y')); ?></dd>
                            </div>
                        </dl>
                    </div>
                </div>

                <!-- Rekomendasi -->
                <div class="bg-white shadow sm:rounded-lg">
                    <div class="px-4 py-5 sm:p-6">
                        <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Rekomendasi Tindakan</h3>
                        <div class="space-y-6">
                            <?php if(isset($recommendations['pertumbuhan'])): ?>
                            <!-- Rekomendasi Pertumbuhan -->
                            <div class="border-l-4 <?php if($recommendations['pertumbuhan']['status'] == 'success'): ?> border-green-400 bg-green-50 <?php elseif($recommendations['pertumbuhan']['status'] == 'warning'): ?> border-yellow-400 bg-yellow-50 <?php else: ?> border-red-400 bg-red-50 <?php endif; ?> p-4 rounded-r-lg">
                                <div class="flex items-start">
                                    <div class="flex-shrink-0">
                                        <?php if($recommendations['pertumbuhan']['status'] == 'success'): ?>
                                            <svg class="h-5 w-5 text-green-400" fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                                            </svg>
                                        <?php elseif($recommendations['pertumbuhan']['status'] == 'warning'): ?>
                                            <svg class="h-5 w-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
                                            </svg>
                                        <?php else: ?>
                                            <svg class="h-5 w-5 text-red-400" fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
                                            </svg>
                                        <?php endif; ?>
                                    </div>
                                    <div class="ml-3 flex-1">
                                        <h4 class="text-sm font-medium <?php if($recommendations['pertumbuhan']['status'] == 'success'): ?> text-green-800 <?php elseif($recommendations['pertumbuhan']['status'] == 'warning'): ?> text-yellow-800 <?php else: ?> text-red-800 <?php endif; ?>">
                                            <?php echo e($recommendations['pertumbuhan']['title']); ?>

                                        </h4>
                                        <p class="mt-1 text-sm <?php if($recommendations['pertumbuhan']['status'] == 'success'): ?> text-green-700 <?php elseif($recommendations['pertumbuhan']['status'] == 'warning'): ?> text-yellow-700 <?php else: ?> text-red-700 <?php endif; ?>">
                                            <?php echo e($recommendations['pertumbuhan']['description']); ?>

                                        </p>
                                        <ul class="mt-3 list-disc list-inside text-sm <?php if($recommendations['pertumbuhan']['status'] == 'success'): ?> text-green-700 <?php elseif($recommendations['pertumbuhan']['status'] == 'warning'): ?> text-yellow-700 <?php else: ?> text-red-700 <?php endif; ?> space-y-1">
                                            <?php $__currentLoopData = $recommendations['pertumbuhan']['actions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($action); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>

                            <?php if(isset($recommendations['perkembangan'])): ?>
                            <!-- Rekomendasi Perkembangan -->
                            <div class="border-l-4 <?php if($recommendations['perkembangan']['status'] == 'success'): ?> border-green-400 bg-green-50 <?php elseif($recommendations['perkembangan']['status'] == 'warning'): ?> border-yellow-400 bg-yellow-50 <?php else: ?> border-red-400 bg-red-50 <?php endif; ?> p-4 rounded-r-lg">
                                <div class="flex items-start">
                                    <div class="flex-shrink-0">
                                        <?php if($recommendations['perkembangan']['status'] == 'success'): ?>
                                            <svg class="h-5 w-5 text-green-400" fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                                            </svg>
                                        <?php elseif($recommendations['perkembangan']['status'] == 'warning'): ?>
                                            <svg class="h-5 w-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
                                            </svg>
                                        <?php else: ?>
                                            <svg class="h-5 w-5 text-red-400" fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
                                            </svg>
                                        <?php endif; ?>
                                    </div>
                                    <div class="ml-3 flex-1">
                                        <h4 class="text-sm font-medium <?php if($recommendations['perkembangan']['status'] == 'success'): ?> text-green-800 <?php elseif($recommendations['perkembangan']['status'] == 'warning'): ?> text-yellow-800 <?php else: ?> text-red-800 <?php endif; ?>">
                                            <?php echo e($recommendations['perkembangan']['title']); ?>

                                        </h4>
                                        <p class="mt-1 text-sm <?php if($recommendations['perkembangan']['status'] == 'success'): ?> text-green-700 <?php elseif($recommendations['perkembangan']['status'] == 'warning'): ?> text-yellow-700 <?php else: ?> text-red-700 <?php endif; ?>">
                                            <?php echo e($recommendations['perkembangan']['description']); ?>

                                        </p>
                                        <ul class="mt-3 list-disc list-inside text-sm <?php if($recommendations['perkembangan']['status'] == 'success'): ?> text-green-700 <?php elseif($recommendations['perkembangan']['status'] == 'warning'): ?> text-yellow-700 <?php else: ?> text-red-700 <?php endif; ?> space-y-1">
                                            <?php $__currentLoopData = $recommendations['perkembangan']['actions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($action); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sigusti.com\resources\views/pemeriksaan/show.blade.php ENDPATH**/ ?>