<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'type' => 'text',
    'name' => null, 
    'id' => null,
    'value' => '', 
    'label' => null,
    'placeholder' => '',
    'required' => false,
    'disabled' => false,
    'readonly' => false,
    'autocomplete' => null,
    'helper' => null,
    'leadingIcon' => null,
    'trailingIcon' => null,
    'floatingLabel' => false,
    'variant' => 'default', // default, inline, floating
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'type' => 'text',
    'name' => null, 
    'id' => null,
    'value' => '', 
    'label' => null,
    'placeholder' => '',
    'required' => false,
    'disabled' => false,
    'readonly' => false,
    'autocomplete' => null,
    'helper' => null,
    'leadingIcon' => null,
    'trailingIcon' => null,
    'floatingLabel' => false,
    'variant' => 'default', // default, inline, floating
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $id = $id ?? $name;
    $baseClasses = 'block w-full px-3 py-2 rounded-md border border-base-light/30 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50';
    $classes = $baseClasses;
    
    if ($disabled) $classes .= ' opacity-60 cursor-not-allowed';
    if ($leadingIcon) $classes .= ' pl-10';
    if ($trailingIcon) $classes .= ' pr-10';
    
    $floatingLabel = $floatingLabel || $variant == 'floating';
    $inlineLabel = $variant == 'inline';
    
    $hasError = $errors->has($name);
    if ($hasError) $classes .= ' border-red-500 focus:border-red-500 focus:ring-red-500';
?>

<div <?php echo e($attributes->class(['mb-4' => !$inlineLabel, 'sm:flex sm:items-center' => $inlineLabel])); ?>>
    <?php if($label && !$floatingLabel): ?>
        <label for="<?php echo e($id); ?>" class="<?php echo e($inlineLabel ? 'sm:w-1/3 pr-2' : ''); ?> block text-sm font-medium <?php echo e($hasError ? 'text-red-600' : 'text-base-dark'); ?> mb-1">
            <?php echo e($label); ?><?php if($required): ?><span class="text-red-500 ml-1">*</span><?php endif; ?>
        </label>
    <?php endif; ?>
    
    <div class="<?php echo e($inlineLabel ? 'sm:w-2/3 mt-1 sm:mt-0' : ''); ?> relative">
        <?php if($leadingIcon): ?>
            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <?php echo $leadingIcon; ?>

            </div>
        <?php endif; ?>
        
        <input 
            x-data
            type="<?php echo e($type); ?>" 
            name="<?php echo e($name); ?>" 
            id="<?php echo e($id); ?>" 
            value="<?php echo e($value); ?>"
            placeholder="<?php echo e($floatingLabel && $label ? ' ' : $placeholder); ?>"
            <?php if($required): ?> required <?php endif; ?>
            <?php if($disabled): ?> disabled <?php endif; ?>
            <?php if($readonly): ?> readonly <?php endif; ?>
            <?php if($autocomplete): ?> autocomplete="<?php echo e($autocomplete); ?>" <?php endif; ?>
            <?php echo e($attributes->except(['class', 'label', 'helper', 'variant'])->merge(['class' => $classes])); ?>

        >
        
        <?php if($floatingLabel && $label): ?>
            <label for="<?php echo e($id); ?>" class="absolute text-sm <?php echo e($hasError ? 'text-red-600' : 'text-base-light'); ?> duration-300 transform 
                <?php echo e(strlen($value) > 0 ? '-translate-y-4 scale-75 top-2 z-10 origin-[0] bg-white px-2 peer-focus:px-2 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4 left-3' : '-translate-y-4 scale-75 top-2 z-10 origin-[0] bg-white px-2 peer-focus:px-2 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4 left-3'); ?>">
                <?php echo e($label); ?><?php if($required): ?><span class="text-red-500 ml-1">*</span><?php endif; ?>
            </label>
        <?php endif; ?>
        
        <?php if($trailingIcon): ?>
            <div class="absolute inset-y-0 right-0 pr-3 flex items-center">
                <?php echo $trailingIcon; ?>

            </div>
        <?php endif; ?>
    </div>
    
    <?php if($helper && !$hasError): ?>
        <p class="<?php echo e($inlineLabel ? 'sm:ml-1/3 sm:pl-2' : ''); ?> mt-1 text-sm text-base-light"><?php echo e($helper); ?></p>
    <?php endif; ?>

    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="<?php echo e($inlineLabel ? 'sm:ml-1/3 sm:pl-2' : ''); ?> mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\laragon\www\sigusti.com\resources\views/components/text-input.blade.php ENDPATH**/ ?>